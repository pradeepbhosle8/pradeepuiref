import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';

// Routing  module
import { AppRoutingModule } from './app-routing.module';

// components
import { AppComponent } from './app.component';
import { AdminComponent } from './admin/admin.component';
import { PublicComponent } from './public/public.component';

// form modules import
import { FormsModule, ReactiveFormsModule  } from '@angular/forms';

// import  ngx pagination module
import {NgxPaginationModule} from 'ngx-pagination';
import { Ng2SearchPipeModule } from 'ng2-search-filter';

// import tiny mc editor
import { EditorModule } from '@tinymce/tinymce-angular';
import { CKEditorModule } from 'ng2-ckeditor';

// import file upload module
import { ImageUploadModule } from 'angular2-image-upload';

// import Toastr Module
 import { ToastrModule } from 'ngx-toastr';
 import {ScrollToModule} from 'ng2-scroll-to';
 import { NgScrollbarModule } from 'ngx-scrollbar';

// http module
import { HttpModule } from '@angular/http';
import { HttpClientModule } from '@angular/common/http';

import { DashboardComponent } from './admin/dashboard/dashboard.component';
import { HeaderComponent } from './admin/dashboard/header/header.component';
import { FooterComponent } from './admin/dashboard/footer/footer.component';
import { PagesMstComponent } from './admin/dashboard/pages/pages-mst/pages-mst.component';
import { AdminMstComponent } from './admin/dashboard/pages/admin-mst/admin-mst.component';
import { ListpageComponent } from './admin/dashboard/pages/pages-mst/listpage/listpage.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { FooterPublicComponent } from './public/footer-public/footer-public.component';
import { HeaderPublicComponent } from './public/header-public/header-public.component';
import { HomeComponent } from './public/pages/home/home.component';
import { AboutComponent } from './public/pages/about/about.component';
import { ResumeComponent } from './public/pages/resume/resume.component';
import { PortfolioComponent } from './public/pages/portfolio/portfolio.component';
import { ContactComponent } from './public/pages/contact/contact.component';

import { ImageFilterPipe } from './share/filter.pipe';
import { ImageComponent } from './public/pages/portfolio/image/image.component';
import { PortfolioMstComponent } from './admin/dashboard/pages/portfolio-mst/portfolio-mst.component';
import { ResumeMstComponent } from './admin/dashboard/pages/resume-mst/resume-mst.component';
import { ExpreienceComponent } from './admin/dashboard/pages/expreience/expreience.component';
import { AddcategoryComponent } from './admin/dashboard/pages/portfolio-mst/addcategory/addcategory.component';


@NgModule({
  declarations: [
    AppComponent,
    AdminComponent,
    PublicComponent,
    DashboardComponent,
    HeaderComponent,
    FooterComponent,
    PagesMstComponent,
    AdminMstComponent,
    ListpageComponent,
    PageNotFoundComponent,
    FooterPublicComponent,
    HeaderPublicComponent,
    HomeComponent,
    AboutComponent,
    ResumeComponent,
    PortfolioComponent,
    ContactComponent,
    ImageFilterPipe,
    ImageComponent,
    PortfolioMstComponent,
    ResumeMstComponent,
    ExpreienceComponent,
    AddcategoryComponent
  ],
  imports: [
    BrowserAnimationsModule,
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    HttpClientModule,
    NgxPaginationModule,
    Ng2SearchPipeModule,
    EditorModule,
    CKEditorModule,
    ToastrModule.forRoot(
      {
        timeOut: 3500,
        positionClass: 'toast-center-center',
      }
    ),
    ScrollToModule.forRoot(),
    NgScrollbarModule,
    ImageUploadModule.forRoot(),


  ],
  providers: [ImageFilterPipe],
  bootstrap: [AppComponent]
})
export class AppModule { }
