import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Components
import { PublicComponent } from './public/public.component';
import { HomeComponent } from './public/pages/home/home.component';
import { AboutComponent } from './public/pages/about/about.component';
import { ResumeComponent } from './public/pages/resume/resume.component';
import { PortfolioComponent } from './public/pages/portfolio/portfolio.component';
import { ImageComponent } from './public/pages/portfolio/image/image.component';

import { ContactComponent } from './public/pages/contact/contact.component';

import { AdminComponent } from './admin/admin.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { DashboardComponent } from './admin/dashboard/dashboard.component';
// dashboard childerne pages
import { PagesMstComponent } from './admin/dashboard/pages/pages-mst/pages-mst.component';
// pages children components

import { ListpageComponent } from './admin/dashboard/pages/pages-mst/listpage/listpage.component';

import { AdminMstComponent } from './admin/dashboard/pages/admin-mst/admin-mst.component';
import { PortfolioMstComponent } from './admin/dashboard/pages/portfolio-mst/portfolio-mst.component';
import { AddcategoryComponent } from './admin/dashboard/pages/portfolio-mst/addcategory/addcategory.component';

import { ResumeMstComponent } from './admin/dashboard/pages/resume-mst/resume-mst.component';
import { ExpreienceComponent } from './admin/dashboard/pages/expreience/expreience.component';

const routes: Routes = [
  {path: '', component: PublicComponent,
    children: [
      {path: '', component: HomeComponent },
      {path: 'about-us', component: AboutComponent },
      {path: 'resume', component: ResumeComponent },
      {path: 'portfolio', component: PortfolioComponent},
      {path: 'image/:port_id', component: ImageComponent},
      {path: 'contact-us', component: ContactComponent }

    ]},
  {path: 'admin', component: AdminComponent },
  {path: 'dashboard', component: DashboardComponent,
        children: [
        {path: '', component: DashboardComponent},
        {path: 'pages', component: PagesMstComponent},
        {path: 'addcategory', component: AddcategoryComponent },
      {path: 'setting', component: AdminMstComponent},
      {path: 'porfolio_mst', component: PortfolioMstComponent},
      {path: 'resume_mst', component: ResumeMstComponent},
      {path: 'expreience', component: ExpreienceComponent}
     ]
  },
  { path: '**', component: PageNotFoundComponent }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
