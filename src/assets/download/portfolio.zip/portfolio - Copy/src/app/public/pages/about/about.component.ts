import { Component, OnInit } from '@angular/core';

import { PageService } from '../../../share/page.service';

import { Pages } from '../../../share/page.module';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {
  users: Pages[] = [];
  private oneOfPages: any = [] = [];
  page_id = 1;
  constructor(
    private service: PageService
  ) { }

  ngOnInit(
  ) {
    this.getpagesOne(this.page_id);
  }

  getpagesOne(page_id: number) {
    this.service.getPageoneDetail(page_id)
    .subscribe((res) => {
      console.log(res);
      this.oneOfPages = Array.of(res);
    });
  }
}
