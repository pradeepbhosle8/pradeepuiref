import { Component, OnInit } from '@angular/core';
import { PageService } from '../../../share/page.service';

import { Pages } from '../../../share/page.module';

@Component({
  selector: 'app-contact',
  templateUrl: './contact.component.html',
  styleUrls: ['./contact.component.css']
})
export class ContactComponent implements OnInit {
  users: Pages[] = [];
  private oneOfPages: any = [] = [];
  page_id = 2;

  constructor(
    private service: PageService
  ) { }

  ngOnInit() {
    this.getpagesOne(this.page_id);
  }

  getpagesOne(page_id: number) {
    this.service.getPageoneDetail(page_id)
    .subscribe((res) => {
    
      this.oneOfPages = Array.of(res);
      console.log(res);
      console.log(this.oneOfPages);
    });
  }

}
