import { Component, OnInit } from '@angular/core';
import { ResumeService } from '../../../share/resume.service';
import { Education } from '../../../share/resume.module';
import { ExpreienceService } from '../../../share/expreience.service';
import { Expreience } from '../../../share/expreience.module';


@Component({
  selector: 'app-resume',
  templateUrl: './resume.component.html',
  styleUrls: ['./resume.component.css']
  
})
export class ResumeComponent implements OnInit {

  EducationList: any ;
  ExpreienceList: any;

  constructor(
    private service: ResumeService,
    private exp_service: ExpreienceService
  ) { }

  ngOnInit() {
 this.getEducationList();
 this. getExpreinceList();
  }

  getEducationList() {
    this.service.getEducation()
    .subscribe((res) => {
      this.EducationList = res.result;

    });
    }

    getExpreinceList() {
      this.exp_service.getExpreience()
      .subscribe((res) => {
        this.ExpreienceList = res.result;
  
      });
      }


}
