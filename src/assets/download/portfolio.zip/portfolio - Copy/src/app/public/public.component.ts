import { Component, OnInit } from '@angular/core';
import {fadeAnimation } from '../share/animation';

@Component({
  selector: 'app-public',
  templateUrl: './public.component.html',
  styleUrls: ['./public.component.css'],
  animations: [fadeAnimation]
})
export class PublicComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
