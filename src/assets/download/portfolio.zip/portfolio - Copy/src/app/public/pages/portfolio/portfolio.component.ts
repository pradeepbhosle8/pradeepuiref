import { Component, Input, OnInit } from '@angular/core';

import { ActivatedRoute, Router } from '@angular/router';


import { ImageService } from '../../../share/image.service';

import { ImageFilterPipe } from '../../../share/filter.pipe';

import { Portfolio } from '../../../share/portfolio.module';
import { Pipe, PipeTransform } from '@angular/core';
import { query, animate, state, stagger, useAnimation, animation, style, transition, keyframes, trigger } from '@angular/animations';

@Component({
  selector: 'app-portfolio',
  templateUrl: './portfolio.component.html',
  styleUrls: ['./portfolio.component.css'],
  animations: [
    trigger('fadeIn', [
      transition(':enter', [
        style({ opacity: '0' }),
        animate('0.5s ease-out', style({ opacity: '1' })),
      ]),
      transition(':leave', [
        style({ opacity: '1' }),
        animate('0.5s ease-out', style({ opacity: '0' })),
      ]),
    ])]
})

export class PortfolioComponent implements OnInit {
  private portfolio: [];
  private cateList: [];
category: any[];
  image: any;
  // Create an input
@Input() filterBy?: any = 'all';

  constructor(
    private imageService: ImageService,
    private router: Router

  ) { }



  ngOnInit() {

    this.getportfolio();
    this. listCategory();
  }

getportfolio() {
   this.imageService.getImages()
   .subscribe((res) => {
     console.log(res);
    this.portfolio = res.result;
   });
  }

  onclick(port_id) {
// console.log(port_id);
this.imageService.getImage(port_id)
.subscribe((res) => {
  this.router.navigate(['/image', port_id]);
});
  }

  // get Category
  listCategory() {
    this.imageService.getCategoryList()
    .subscribe((res) => {
   this.cateList = res.result;
  });
    }




  }




