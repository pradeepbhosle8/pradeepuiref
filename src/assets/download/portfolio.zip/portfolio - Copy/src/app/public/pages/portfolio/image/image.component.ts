import { Component, OnInit } from '@angular/core';
import {Location} from '@angular/common';
import { ActivatedRoute } from '@angular/router';

import { ImageService } from '../../../../share/image.service';
import { Pipe, PipeTransform } from '@angular/core';

@Component({
  selector: 'app-image',
  templateUrl: './image.component.html',
  styleUrls: ['./image.component.css']
})
export class ImageComponent implements OnInit {
  image: any = [] = [];

  private portfolioImg: any = [];
  private test: [];

  constructor(
    private imageService: ImageService,
    private route: ActivatedRoute,
    private _location: Location
  ) { }

  ngOnInit() {
    this.ongetOneImage(this.route.snapshot.params['port_id']);
  }

ongetOneImage(port_id: number) {
    this.imageService.getImage(this.route.snapshot.params['port_id'])
    .subscribe((res) => {
     this.image = Array.of(res.result);
     console.log(this.image);
 });
}

back() {
 this._location.back();
}


}

