import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PagesMstComponent } from './pages-mst.component';

describe('PagesMstComponent', () => {
  let component: PagesMstComponent;
  let fixture: ComponentFixture<PagesMstComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PagesMstComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PagesMstComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
