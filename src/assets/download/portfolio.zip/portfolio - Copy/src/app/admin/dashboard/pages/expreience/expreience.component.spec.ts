import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ExpreienceComponent } from './expreience.component';

describe('ExpreienceComponent', () => {
  let component: ExpreienceComponent;
  let fixture: ComponentFixture<ExpreienceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ExpreienceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ExpreienceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
