import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import { NgForm } from '@angular/forms';
import { CategoryService } from '../../../../../share/category.service';
import { Pipe, PipeTransform } from '@angular/core';
import { Category } from '../../../../../share/category.module';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-addcategory',
  templateUrl: './addcategory.component.html',
  styleUrls: ['./addcategory.component.css'],
  providers: [CategoryService]
})
export class AddcategoryComponent implements OnInit {
  admins: any ;
  regModel: any = [];
  showNewCategoryForm: Boolean = false;
  CategorySectionList: Boolean = true;
  submitType: String = 'Save';

  constructor(
    private _services: CategoryService,
    private toastr: ToastrService
  ) { }

  ngOnInit() {
    this.getCategoryList();
    this.resetForm();
  }

  newAdd() {
    this.showNewCategoryForm = true;
    this.CategorySectionList = false;
    this.submitType = 'Save';
}

closeAdminForm() {
   this.showNewCategoryForm = false;
   this.CategorySectionList = true;
   this.resetForm();
}

// get all adminlist record
getCategoryList() {
  this._services.getCategoryList()
  .subscribe((res) => {
    console.log(res);
  this.admins = res.result;
  });
  }

  // reset form admin
  resetForm(form?: NgForm) {
    if ( form != null) {
    form.reset();
    }
    this._services.selectedCategoryRec = {
    cat_id: null,
    category: ''
     };
    }

    // add admin recoard
    onSubmit(form: NgForm) {
      if (form.value.admin_id == null) {
          console.log(form.value);
        this._services.addCategory(form.value)
       .subscribe((res) => {
         this.submitType = 'Save';
         this.getCategoryList();
         this.toastr.success('New Pages Record Add Sucessfully');
         this.resetForm();
         this.showNewCategoryForm = false;
         this.CategorySectionList = true;
        });
        } else {
          this._services.editCategory(form.value.page_id, form.value)
           .subscribe((res) => {
            this.getCategoryList();
           this.toastr.info('Record Update Sucessfully');
           this.resetForm();
           this.showNewCategoryForm = false;
           this.CategorySectionList = true;
         });
  }
}

// edit admin recaord
editCategoryrecoard(categ: Category) {
  this.showNewCategoryForm = true;
  this.CategorySectionList = false;
  this._services.selectedCategoryRec = Object.assign({}, categ);
  this.submitType = 'Update';
}

// delete admin recaord
deleteCategoryrecaord(cat_id: number) {
if (confirm('Are You Sure to delete this Admin ' + cat_id) === true) {
this._services.deleteCategory(cat_id)
.subscribe((res) => {
this.getCategoryList();
this.toastr.success('Record Deleted Sucessfully');
});
}
}





}
