    import { Component, OnInit } from '@angular/core';
// import activeroute and rout which help for redirect path
    import {ActivatedRoute, Router} from '@angular/router';
    import { NgForm } from '@angular/forms';
// import admin services module
    import { AdminService } from '../../../../share/admin.service';
// import Pipe module which help for searching and logn text ..
    import { Pipe, PipeTransform } from '@angular/core';
// admin ts file add
    import { Admin } from '../../../../share/admin.module';
// import toaster notification mododule
  import { ToastrService } from 'ngx-toastr';



    @Component({
    selector: 'app-admin-mst',
    templateUrl: './admin-mst.component.html',
    styleUrls: ['./admin-mst.component.css'],
    providers: [AdminService]
    })


    export class AdminMstComponent implements OnInit {
    admins: any ;
    regModel: any = [];
    showNewAdminForm: Boolean = false;
    adminSectionList: Boolean = true;
    submitType: String = 'Save';

    constructor(
// import services
    private _services: AdminService,
    private toastr: ToastrService
    ) { }

    ngOnInit() {

    this.resetForm();
// push admin recoard
    this.getAdminList();
    }

    newAdd() {
        this.showNewAdminForm = true;
        this.adminSectionList = false;
        this.submitType = 'Save';
   }

   closeAdminForm() {
       this.showNewAdminForm = false;
       this.adminSectionList = true;
       this.resetForm();
   }


// get all adminlist record
    getAdminList() {
    this._services.getAdmin()
    .subscribe((res) => {
    this.admins = res.result;
    });
    }

// reset form admin
    resetForm(form?: NgForm) {
    if ( form != null) {
    form.reset();
    }
    this._services.selectedAdminRec = {
    admin_id: null,
    full_name: '',
    email_id: '',
    mobile_no: '',
    date: '',
    admin_img: '',
    username: '',
    password: '',
    gender: ''
    };
    }

// add admin recoard
    onSubmit(form: NgForm) {
        if (form.value.admin_id == null) {
            console.log(form.value);
          this._services.addAdmin(form.value)
         .subscribe((res) => {
           this.submitType = 'Save';
           this._services.getAdmin();
           this.getAdminList();
           this.toastr.success('New Pages Record Add Sucessfully');
           this.resetForm();
           this.showNewAdminForm = false;
           this.adminSectionList = true;
          });
          } else {
            this._services.editAdmin(form.value.page_id, form.value)
             .subscribe((res) => {
                this._services.getAdmin();
                this.getAdminList();
             this.toastr.info('Record Update Sucessfully');
             this.resetForm();
             this.showNewAdminForm = false;
             this.adminSectionList = true;
           });
    }
}

// edit admin recaord
    editAdminrecoard(admin: Admin) {
        this.showNewAdminForm = true;
        this.adminSectionList = false;  
        this._services.selectedAdminRec = Object.assign({}, admin);
        this.submitType = 'Update';
    }

// delete admin recaord
    deleteAdminrecaord(admin_id: number) {
    if (confirm('Are You Sure to delete this Admin ' + admin_id) === true) {
    this._services.deleteAdmin(admin_id)
    .subscribe((res) => {
    this.getAdminList();
    this.toastr.success('Record Deleted Sucessfully');
    });
    }
    }



}
