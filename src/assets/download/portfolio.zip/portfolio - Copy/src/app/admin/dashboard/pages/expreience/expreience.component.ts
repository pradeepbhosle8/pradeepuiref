import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Pipe, PipeTransform } from '@angular/core';
import { NgForm } from '@angular/forms';
import {ActivatedRoute, Router} from '@angular/router';
import { ExpreienceService } from '../../../../share/expreience.service';
import { Expreience } from '../../../../share/expreience.module';

@Component({
  selector: 'app-expreience',
  templateUrl: './expreience.component.html',
  styleUrls: ['./expreience.component.css'],
  providers: [ExpreienceService]
})
export class ExpreienceComponent implements OnInit {
  ExpreienceList: any ;
  showExpreinceForm: Boolean = false;
  experiencesectionDetails: Boolean = true;
  submitType: String = 'Save';

  constructor(
  private _services: ExpreienceService,
  private toastr: ToastrService
  ) { }

  ngOnInit() {
    this.getExpreienceList();
    this.resetForm();
  }

  getExpreienceList() {
    this._services.getExpreience()
    .subscribe((res) => {
      this.ExpreienceList = res.result;
    });
    }

     // reset form
  resetForm(form?: NgForm) {
    if (form != null)  {
      form.reset();
    }
    this._services.selectedExpreienceRec = {
      exprience_id: null,
      start_year: '',
      end_year: '',
      exprience_title: '',
      office_name: '',
      exprience_description: ''
    };
    }

  // add expreience form
  newAddExp() {
    this.showExpreinceForm = true;
    this.experiencesectionDetails = false;
    }
  // close experience form
  closeExperienceForm() {
    this.showExpreinceForm = false;
    this.experiencesectionDetails = true;
    this.resetForm();
  }

  editExpreiencerecoard(exprei: Expreience) {
    this.showExpreinceForm = true;
    this.experiencesectionDetails = false;
    this._services.selectedExpreienceRec = Object.assign({}, exprei);
        this.submitType = 'Update';
  }

   // add form recoard
   onSubmit(form: NgForm) {
    if (form.value.exprience_id == null) {
     this._services.addExpreience(form.value)
      .subscribe((res) => {
      this.submitType = 'Save';
      this.getExpreienceList();
      this.toastr.success('New Education Record Add Sucessfully');
      this.resetForm();
      this.experiencesectionDetails = true;
      this.showExpreinceForm = false;
      });
    } else {
      this._services.editExpreience(form.value.exprience_id, form.value)
       .subscribe((res) => {
        this.getExpreienceList();
       this.toastr.info('Record Update Sucessfully');
       this.resetForm();
       this.experiencesectionDetails = true;
       this.showExpreinceForm = false;
     });
}

    }

     // delete recoard
     deleteEducationRecod(exprience_id: number) {
      if (confirm('Are you sure to delete this Record id' + exprience_id) === true ) {
       this._services.deleteExpreience(exprience_id)
       .subscribe((res) => {
         this.getExpreienceList();
         this.toastr.success('Record Deleted Sucessfully');
       });
       }
     }


}
