  import { Component, OnInit } from '@angular/core';
  import { ToastrService } from 'ngx-toastr';
  import { Pipe, PipeTransform } from '@angular/core';
  import { NgForm } from '@angular/forms';
  import {ActivatedRoute, Router} from '@angular/router';
  import { ResumeService } from '../../../../share/resume.service';
  import { Education } from '../../../../share/resume.module';

  @Component({
  selector: 'app-resume-mst',
  templateUrl: './resume-mst.component.html',
  styleUrls: ['./resume-mst.component.css'],
  providers: [ResumeService]
  })
  export class ResumeMstComponent implements OnInit {
  EducationList: any ;
  showEducationForm: Boolean = false;
  experienceListDetails: Boolean = true;
  submitType: String = 'Save';

  constructor(
  private _services: ResumeService,
  private toastr: ToastrService
  ) { }

  ngOnInit() {
    this.getEducationList();
    this.resetForm();
  }

  getEducationList() {
  this._services.getEducation()
  .subscribe((res) => {
    console.log(res.result);
    this.EducationList = res.result;
  });
  }

  // reset form
  resetForm(form?: NgForm) {
    if (form != null)  {
      form.reset();
    }
    this._services.selectedEducationRec = {
      educ_id: null,
      title: '',
      university: '',
      description: '',
      passing_year: '',
    };
    }



  newAddeducation() {
    this.showEducationForm = true;
    this.experienceListDetails = false;
  }
   // close experience form
   closeEducationForm() {
    this.showEducationForm = false;
    this.experienceListDetails = true;
    this.resetForm();
  }

  editEducationListrecoard(education: Education) {
    this.showEducationForm = true;
    this.experienceListDetails = false;
    this._services.selectedEducationRec = Object.assign({}, education);
        this.submitType = 'Update';
  }

  // add form recoard
  onSubmit(form: NgForm) {
    if (form.value.educ_id == null) {
     this._services.addEducation(form.value)
      .subscribe((res) => {
      this.submitType = 'Save';
      this.getEducationList();
      this.toastr.success('New Education Record Add Sucessfully');
      this.resetForm();
      this.experienceListDetails = true;
      this.showEducationForm = false;
      });
    } else {
      this._services.editEducation(form.value.page_id, form.value)
       .subscribe((res) => {
        this.getEducationList();
       this.toastr.info('Record Update Sucessfully');
       this.resetForm();
       this.experienceListDetails = true;
       this.showEducationForm = false;
     });
}

    }

    // delete recoard
    deleteEducationRecod(educ_id: number) {
     if (confirm('Are you sure to delete this Record id' + educ_id) === true ) {
      this._services.deleteEducation(educ_id)
      .subscribe((res) => {
        this.getEducationList();
        this.toastr.success('Record Deleted Sucessfully');
      });
      }
    }



}
