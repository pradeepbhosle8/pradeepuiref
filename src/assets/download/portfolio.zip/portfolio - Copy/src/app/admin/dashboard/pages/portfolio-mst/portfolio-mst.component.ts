import { Component,  OnInit, ViewChild  } from '@angular/core';


import { NgForm } from '@angular/forms';

import { ImageService } from '../../../../share/image.service';
import { Pipe, PipeTransform } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { Portfolio } from '../../../../share/portfolio.module';



@Component({
  selector: 'app-portfolio-mst',
  templateUrl: './portfolio-mst.component.html',
  styleUrls: ['./portfolio-mst.component.css'],
  providers: [ImageService]
})
export class PortfolioMstComponent implements OnInit {

  private pageList: Portfolio[];
  catemodel: any = [];
  private portList: [];
  private cateList: [];
  name = 'ng2-ckeditor';
  ckeConfig: any = '';
  imageUrl = '';
  fileToUpload: File = null;

  description: string;
  url: string;

  showNewtableList: Boolean = true;
  showNewPortfolioForm: Boolean = false;
  submitType: String = 'Save';
  str: string ;
  @ViewChild('description') ckeditor: any ;

  constructor(
   private service: ImageService,
   private toastr: ToastrService,
  


  ) {}


  ngOnInit() {

    this.ckeConfig = {
      allowedContent: false,
      extraPlugins: 'divarea',
      forcePasteAsPlainText: true

    };


    this.resetForm();
    this.getallPortfolio();
    this.getCateList();
  }



  fileChange(file: FileList) {
  this.fileToUpload = file.item(0);

  // show image preview
  const render = new FileReader();
  render.onload = (event: any) => {
  this.imageUrl = event.target.result;

  };
  render.readAsDataURL(this.fileToUpload);

    }



  // get all
  getallPortfolio() {
    this.service.getImages()
    .subscribe((res) => {
      this.portList = res.result;
    });
    }

  // get category
  getCateList() {

  this.service.getCategoryList()
  .subscribe((res) => {
  this.cateList = res.result;
  });
  }

  // add portfolio click
  newPortfolio() {
    this.showNewPortfolioForm = true;
    this.submitType = 'Save';
  
    this.showNewtableList = false;
  }


  closePortfolioForm() {
this.showNewPortfolioForm = false;
this.showNewtableList = true ;
this.resetForm();
  }


    // add category click
    newCategory() {
    
      this.submitType = 'Save';
      this.showNewPortfolioForm = false;
      this.showNewtableList = false;
    }

   // reset form portfolio
   resetForm(form?: NgForm) {
    if ( form != null ) {
        form.reset();
      }
    this.service.selectedPortfolio = {
      port_id: null,
      cat_id: null,
      caption: '',
      url: '',
      client: '',
      date: '',
      skill: '',
      description: '',
      visit_website: ''
   
 };
  }

// inser portfolio
    onSubmitPortfolio(form: NgForm) {
    if (form.value.port_id == null) {
    form.value.url = this.fileToUpload.name;
    console.log(form.value);
      console.log(this.fileToUpload);
    this.service.addPortfoliolist(form.value, this.fileToUpload)
    .subscribe((res => {
    this.getallPortfolio();
    this.toastr.success('New Pages Record Add Sucessfully');
    this.resetForm();
    this.showNewPortfolioForm = false;
    this.showNewtableList = true;
    }));

    } else {
      console.log(form.value.port_id);
    this.service.EditPortfoliolist(form.value.port_id, form.value)
    .subscribe((res) => {
    this.getallPortfolio();
    this.toastr.info('Record Update Sucessfully');
    this.resetForm();
    this.showNewPortfolioForm = false;
    this.showNewtableList = true;
   });
    }
    }

editPort(page: Portfolio) {
  this.showNewPortfolioForm = true;
 this.showNewtableList = false ;
  this.service.selectedPortfolio = Object.assign({}, page);
  this.submitType = 'Update';
  }

  deletePortData(port_id: number) {
  if (confirm('Are you Sure to delete this Record?' + port_id) === true) {
  this.service.deletePortfolioList(port_id)
  .subscribe((res) => {
  this.getallPortfolio();

  this.toastr.success('Record Deleted Sucessfully');
  });
  }
  }

  }







  // onSubmit(portfolioForm) {
  //   console.log('Working');
  //   console.log(portfolioForm.value);
  // }


