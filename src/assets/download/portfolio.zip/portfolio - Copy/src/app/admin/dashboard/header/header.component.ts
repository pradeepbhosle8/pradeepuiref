import { Component, OnInit } from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';

// import serivce module
import { AdminService } from '../../../share/admin.service';

import { Pipe, PipeTransform } from '@angular/core';

import { Admin } from '../../../share/admin.module';
import { Pages } from 'src/app/share/page.module';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  admin: any = {};
  errorMsg = '';
  constructor(
    private _service: AdminService,
    private router: Router,
  ) { }

  ngOnInit() {
  }


  // logout() {
  //   this._service.loginAuth()
  //   .subscribe((res)  =>  {
  //     this.admin.username = '';
  //     this.admin.password = '';
  //     this.router.navigate(['/admin'], {skipLocationChange: true });

  //  });

  // }


}
