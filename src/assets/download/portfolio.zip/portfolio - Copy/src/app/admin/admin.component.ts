import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators, ReactiveFormsModule   } from '@angular/forms';
import {ActivatedRoute, Router} from '@angular/router';
import { NgForm } from '@angular/forms';



import {
  trigger,
  keyframes,
  animate,
  transition,
  style,
  query
} from '@angular/animations';

// import serivce module
 import { AdminService } from '../share/admin.service';
import { Admin } from '../share/admin.module';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css'],
  animations: [
    trigger('wobble', [
      transition('inactive => active', animate(1000, keyframes([
        style({transform: 'translate3d(-25%, 0, 0) rotate3d(0, 0, 1, -5deg)', offset: .15}),
        style({transform: 'translate3d(20%, 0, 0) rotate3d(0, 0, 1, 3deg)', offset: .30}),
        style({transform: 'translate3d(-15%, 0, 0) rotate3d(0, 0, 1, -3deg)', offset: .45}),
        style({transform: 'translate3d(10%, 0, 0) rotate3d(0, 0, 1, 2deg)', offset: .60}),
        style({transform: 'translate3d(-5%, 0, 0) rotate3d(0, 0, 1, -1deg)', offset: .75}),
        style({transform: 'none', offset: 1}),
      ]))),
    ])
  ]
})
export class AdminComponent implements OnInit {

admin: any = {};

errorMsg = '';
public wobbleState: string;

  constructor(
    private router: Router,
    private _service: AdminService
 
    ) { }

  ngOnInit() {
  }

  reset() {
    this.wobbleState = 'inactive';

  }
  // login
  onSubmit() {
    if (this.admin.username === 'pradeep07' && this.admin.password === 'pradeep@kevu07') {
      this.router.navigate(['/dashboard']);
      } else {
      this.wobbleState = 'active';
     this.errorMsg = 'Invalid Username and password';
}
   // alert('SUCCESS!! :-)\n\n' + JSON.stringify(this.user));
  }

  }




