import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PortfolioMstComponent } from './portfolio-mst.component';

describe('PortfolioMstComponent', () => {
  let component: PortfolioMstComponent;
  let fixture: ComponentFixture<PortfolioMstComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PortfolioMstComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PortfolioMstComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
