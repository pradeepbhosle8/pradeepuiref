import { Component, OnInit, ViewChild  } from '@angular/core';
import { NgForm } from '@angular/forms';
// import serivce module
 import { PageService } from '../../../../share/page.service';
 import { Pages } from '../../../../share/page.module';
 import { Pipe, PipeTransform } from '@angular/core';
 import { ToastrService } from 'ngx-toastr';



@Component({
  selector: 'app-pages-mst',
  templateUrl: './pages-mst.component.html',
  styleUrls: ['./pages-mst.component.css']

})
export class PagesMstComponent implements OnInit {
  name = 'ng2-ckeditor';
  ckeConfig: any;
  page_content: string;




  @ViewChild('page_content') ckeditor: any ;



  pageList: any;
  regModel: any = [];
  showNewPagesForm: Boolean = false;
  pagesListDetails_Container: Boolean = true;
  submitType: String = 'Save';

 constructor(
    private service: PageService,
    private toastr: ToastrService
  ) { }


  ngOnInit() {

    this.ckeConfig = {
      allowedContent: false,
      extraPlugins: 'divarea',
      forcePasteAsPlainText: true

    };

this.resetForm();
this.getpagesList();
  }

  resetForm(form?: NgForm) {
    if ( form != null) {
      form.reset();
    }
      this.service.selectedPages = {
      page_id: null,
      page_title: '',
      page_content: '',
      date: '',
      };
  }

  // function click add open form
  newAdd() {
      this.showNewPagesForm = true;
      this.pagesListDetails_Container = false;
      this.submitType = 'Save';

    }

    closePagesForm() {
      console.log('Working');
    this.showNewPagesForm = false;
    this.pagesListDetails_Container = true;
    this.resetForm();
  }

    onSubmit(form: NgForm) {
    if (form.value.page_id == null) {
          console.log(form.value);
        this.service.postPage(form.value)
          .subscribe((res) => {
          this.submitType = 'Save';
          this.service.getPagelistDetail();
          this.getpagesList();
          this.toastr.success('New Pages Record Add Sucessfully');
          this.resetForm();
          this.showNewPagesForm = false;
          this.pagesListDetails_Container = true;
        });
        } else {
         this.service.putPage(form.value.page_id, form.value)
          .subscribe((res) => {
           this.service.getPagelistDetail();
          this.getpagesList();
          this.toastr.info('Record Update Sucessfully');
          this.resetForm();
          this.pagesListDetails_Container = true;
          this.showNewPagesForm = false;

        });
      }
    }

  // Get all pages list details
  getpagesList() {
      this.service.getPagelistDetail()
      .subscribe((res) => {
        console.log(res);
        this.pageList = res.result;
     });
    }



  // edit page fro page list
  editPage(page: Pages) {
    this.showNewPagesForm = true;
    this.pagesListDetails_Container = false;
    this.service.selectedPages = Object.assign({}, page);
    this.submitType = 'Update';
    }

    deletePageData(page_id: number) {
      if (confirm('Are you Sure to delete this Record?' + page_id) === true) {
        this.service.deleteusers(page_id)
        .subscribe((res) => {
        this.getpagesList();
        this.toastr.success('Record Deleted Sucessfully');
        });
      }
    }


}


