import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-portfolio',
  templateUrl: './add-portfolio.component.html',
  styleUrls: ['./add-portfolio.component.css']
})
export class AddPortfolioComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
