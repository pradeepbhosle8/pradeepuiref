import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ResumeMstComponent } from './resume-mst.component';

describe('ResumeMstComponent', () => {
  let component: ResumeMstComponent;
  let fixture: ComponentFixture<ResumeMstComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ResumeMstComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ResumeMstComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
