export class Admin {
    admin_id: string;
    full_name: string;
    email_id: string;
    mobile_no: string;
    date: string;
    admin_img: string;
    username: string;
    password: string;
    gender: string;

}
