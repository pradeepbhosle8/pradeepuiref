import { Injectable } from '@angular/core';
// http module import
    import { Http, Response, Headers, RequestOptions} from '@angular/http';
    import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';

    import { Observable } from 'rxjs/RX';
    import 'rxjs/add/operator/map';
    import 'rxjs/add/operator/catch';
    import 'rxjs/add/observable/throw';
// import admin module ts
    import { Category } from './category.module';

@Injectable({
  providedIn: 'root'
})
export class CategoryService {
  categ: Category;
  selectedCategoryRec: Category;

  private headers = new Headers({'Content-Type': 'application/json'});
  private options = new RequestOptions({headers: this.headers});

  constructor(
    private _http: Http,
  ) { }

  // get all Categoty record
  getCategoryList() {
    const slimUrl = 'http://localhost:8080/api/category';
    return this._http.get(slimUrl)
    .map((res: Response) => {
        return {status: res.status, result: res.json() };
    });
    }

// add Categoty record
    addCategory(categ: Category) {
    const slimUrl = 'http://localhost:8080/api/category/add';
    const data = {
      category: categ.category,
    };
    return this._http.post(slimUrl, data, this.options)
    .map((res: Response) => {
        return {status: res.status, result: res.json() };
    });
    }

// edit admin record
    editCategory(cat_id, categ) {
    const slimUrl = 'http://localhost:8080/api/category/update/' + categ.cat_id;
    const params = new HttpParams().set('cat_id', categ.cat_id);
    const headers = new HttpHeaders().set('content-type', 'application/json');
    const data = {
    category: categ.category,
    cat_id: categ.cat_id
    };
    return this._http.put(slimUrl, data, {params})
    .map((res: Response) => {
        res.json();
    });

    }

// delete record from category
    deleteCategory(cat_id: number) {
    const slimUrl = 'http://localhost:8080/api/category/delete/' + cat_id;
    return this._http.delete(slimUrl, this.options)
    .map((res: Response ) => {
    JSON.stringify(res);
    });
    }


}
