export class Education {
    educ_id: number;
    title: string;
    university: string;
    description: string;
    passing_year: string;

}
