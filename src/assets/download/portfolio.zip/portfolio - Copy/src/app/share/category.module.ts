export class Category {
    cat_id: string;
    category: string;

}
