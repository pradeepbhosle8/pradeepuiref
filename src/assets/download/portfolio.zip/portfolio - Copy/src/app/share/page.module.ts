export class Pages {
    page_id: string;
    page_title: string;
    page_content: string;
    date: string;

}
