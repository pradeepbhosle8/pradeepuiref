import { Pipe, PipeTransform } from '@angular/core';


@Pipe({name: 'imageFilter'})

export class ImageFilterPipe implements PipeTransform {
    // take certain items and criteria
    transform(items: any[], criteria: any): any {
        if (criteria === 'all') {
         return items;

        } else {
            return items.filter(item => {
                console.log(item);
              return item.category === criteria;
            });
        }
    }
}
