export class Expreience {
    exprience_id: string;
    start_year: string;
    end_year: string;
    exprience_title: string;
    office_name: string;
    exprience_description: string;

}
