  import { Injectable } from '@angular/core';
  // http module import
  import { Http, Response, Headers, RequestOptions} from '@angular/http';
  import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';

  import { Observable } from 'rxjs/RX';
  import 'rxjs/add/operator/map';
  import 'rxjs/add/operator/catch';
  import 'rxjs/add/observable/throw';
  // import Education module ts
  import { Education } from './resume.module';

  @Injectable({
  providedIn: 'root'
  })

  export class ResumeService {
  education: Education;
  selectedEducationRec: Education;

  private headers = new Headers({'Content-Type': 'application/json'});
  private options = new RequestOptions({headers: this.headers});

  constructor(
  private _http: Http,
  ) { }


  // get all Experience record
  getEducation() {
  const slimUrl = 'http://localhost:8080/api/education';
  return this._http.get(slimUrl)
  .map((res: Response) => {
  return {status: res.status, result: res.json() };
  });
  }

  // add Education record
  addEducation(education: Education) {
  const slimUrl = 'http://localhost:8080/api/education/add';
  const data = {
  title: education.title,
  university: education.university,
  description: education.description,
  passing_year: education.passing_year
  };
  return this._http.post(slimUrl, data, this.options)
  .map((res: Response) => {
  return {status: res.status, result: res.json() };
  });
  }

  // edit Education record
  editEducation(educ_id, education) {
  const slimUrl = 'http://localhost:8080/api/education/update/' + education.educ_id;
  const params = new HttpParams().set('educ_id', education.educ_id);
  const headers = new HttpHeaders().set('content-type', 'application/json');
  const data = {
  title: education.title,
  university: education.university,
  exprience_title: education.exprience_title,
  description: education.description,
  passing_year: education.passing_year
  };
  return this._http.put(slimUrl, data, {params})
  .map((res: Response) => {
  res.json();
  });

  }

  // delete record from education
  deleteEducation(educ_id: number) {
  const slimUrl = 'http://localhost:8080/api/education/delete/' + educ_id;
  return this._http.delete(slimUrl, this.options)
  .map((res: Response ) => {
  JSON.stringify(res);
  });
  }



  }
