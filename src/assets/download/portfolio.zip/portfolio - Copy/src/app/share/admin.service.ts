    import { Injectable } from '@angular/core';
// http module import
    import { Http, Response, Headers, RequestOptions} from '@angular/http';
    import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';

    import { Observable } from 'rxjs/RX';
    import 'rxjs/add/operator/map';
    import 'rxjs/add/operator/catch';
    import 'rxjs/add/observable/throw';
// import admin module ts
    import { Admin } from './admin.module';




    @Injectable({
    providedIn: 'root'
    })
    export class AdminService {

    admin: Admin;
    selectedAdminRec: Admin;

    private headers = new Headers({'Content-Type': 'application/json'});
    private options = new RequestOptions({headers: this.headers});

    constructor(
    private _http: Http,

    ) { }

    loginAuth(admin: Admin) {
    const url = 'http://localhost:8080/api/admin/login';
    const headers = new HttpHeaders().set('content-type', 'application/json');
    const body = {
      username: admin.username,
      password: admin.password,
      };
    return this._http.post(url,  body , this.options)
    .map((res: Response) => {
        return {status: res.status, result: res.json() };
    });
    }

// get all admin record
    getAdmin() {
    const slimUrl = 'http://pradeepbhosle.lifekeepteaching.com/deployspislim/public/api/admin';
    return this._http.get(slimUrl)
    .map((res: Response) => {
        return {status: res.status, result: res.json() };
    });
    }

// add admin record
    addAdmin(admin: Admin) {
    const slimUrl = 'http://localhost:8080/api/admin/add';
    const data = {
    full_name: admin.full_name,
    email_id: admin.email_id,
    mobile_no: admin.mobile_no,
    date: admin.date,
    admin_img: admin.admin_img,
    username: admin.username,
    password: admin.password,
    gender: admin.gender
    };
    return this._http.post(slimUrl, data, this.options)
    .map((res: Response) => {
        return {status: res.status, result: res.json() };
    });
    }

// edit admin record
    editAdmin(admin_id, admin) {
    const slimUrl = 'http://localhost:8080/api/admin/update/' + admin.admin_id;
    const params = new HttpParams().set('admin_id', admin.admin_id);
    const headers = new HttpHeaders().set('content-type', 'application/json');
    const data = {
    full_name: admin.full_name,
    email_id: admin.email_id,
    mobile_no: admin.mobile_no,
    date: admin.date,
    admin_img: admin.admin_img,
    username: admin.username,
    password: admin.password,
    gender: admin.gender,
    admin_id: admin.admin_id
    };
    return this._http.put(slimUrl, data, {params})
    .map((res: Response) => {
        res.json();
    });

    }

// delete record from admin
    deleteAdmin(admin_id: number) {
    const slimUrl = 'http://localhost:8080/api/admin/delete/' + admin_id;
    return this._http.delete(slimUrl, this.options)
    .map((res: Response ) => {
    JSON.stringify(res);
    });
    }








}
