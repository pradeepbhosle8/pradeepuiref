    import { Injectable } from '@angular/core';
    // http module import
    import { Http, Response, Headers, RequestOptions} from '@angular/http';
    import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';

    import { Observable } from 'rxjs/RX';
    import 'rxjs/add/operator/map';
    import 'rxjs/add/operator/catch';
    import 'rxjs/add/observable/throw';
    // import admin module ts
    import { Expreience } from './expreience.module';

    @Injectable({
    providedIn: 'root'
    })
    export class ExpreienceService {
    exprei: Expreience;
    selectedExpreienceRec: Expreience;

    private headers = new Headers({'Content-Type': 'application/json'});
    private options = new RequestOptions({headers: this.headers});

    constructor(
      private _http: Http,
    ) { }

    // get all Experience record
    getExpreience() {
    const slimUrl = 'http://localhost:8080/api/expreience';
    return this._http.get(slimUrl)
    .map((res: Response) => {
    return {status: res.status, result: res.json() };
    });
    }

    // add Experience record
    addExpreience(exprei: Expreience) {
    const slimUrl = 'http://localhost:8080/api/expreience/add';
    const data = {
    start_year: exprei.start_year,
    end_year: exprei.end_year,
    exprience_title: exprei.exprience_title,
    office_name: exprei.office_name,
    exprience_description: exprei.exprience_description,
    };
    return this._http.post(slimUrl, data, this.options)
    .map((res: Response) => {
    return {status: res.status, result: res.json() };
    });
    }

    // edit Experience record
    editExpreience(exprience_id, exprei) {
    const slimUrl = 'http://localhost:8080/api/expreience/update/' + exprei.exprience_id;
    const params = new HttpParams().set('exprience_id', exprei.exprience_id);
    const headers = new HttpHeaders().set('content-type', 'application/json');
    const data = {
    start_year: exprei.start_year,
    end_year: exprei.end_year,
    exprience_title: exprei.exprience_title,
    office_name: exprei.office_name,
    exprience_description: exprei.exprience_description,
    exprience_id: exprei.exprience_id
    };
    return this._http.put(slimUrl, data, {params})
    .map((res: Response) => {
    res.json();
    });

    }

    // delete record from expreience
    deleteExpreience(exprience_id: number) {
    const slimUrl = 'http://localhost:8080/api/expreience/delete/' + exprience_id;
    return this._http.delete(slimUrl, this.options)
    .map((res: Response ) => {
    JSON.stringify(res);
    });
    }



    }
