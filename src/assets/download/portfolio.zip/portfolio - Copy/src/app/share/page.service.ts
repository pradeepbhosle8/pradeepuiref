    import { Injectable } from '@angular/core';
// import page module ts
    import { Pages } from './page.module';
// http module import
    import { Http, Response, Headers, RequestMethod, RequestOptions} from '@angular/http';
    import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
    import { Observable } from 'rxjs/Observable';
    import 'rxjs/add/operator/map';
    import 'rxjs/add/operator/toPromise';
    import { from } from 'rxjs';
    import { Body } from '@angular/http/src/body';
    import { Page } from 'ngx-pagination/dist/pagination-controls.directive';



    @Injectable({
    providedIn: 'root'
    })

    export class PageService {
    checkMe: any;
    selectedPages: Pages;
    page: Pages;

    private headers = new Headers({'Content-Type': 'application/json'});
    private options = new RequestOptions({headers: this.headers});

    constructor(
    private _http: Http,
    ) { }

// get all pages details from databas
    getPagelistDetail() {
    const slimUrl = 'http://localhost:8080/api/pages';
    return this._http.get(slimUrl)
    .map((res: Response) => {
        return {status: res.status, result: res.json() };
    });
    }

// get id pages details from databas
    getPageoneDetail(page_id) {
    const pageurl = 'http://localhost:8080/api/pages/' + page_id;
    return this._http.get(pageurl, this.options)
    .map((res: Response) => res.json());
    }

// add page from form to databas
    postPage(page: Pages) {
    const pageurl = 'http://localhost:8080/api/pages/add';
    const data = {
        page_title: page.page_title,
        page_content: page.page_content,
        date: page.date
        };
    return this._http.post(pageurl, data, this.options )
    .map((res: Response) => {
        return {status: res.status, result: res.json() };
    });

    }

// edit page
    putPage(page_id, page) {
    const pageUrl = 'http://localhost:8080/api/pages/update/' + page.page_id;
    const params = new HttpParams().set('admin_id', page.page_id);
    const data = {
        page_title: page.page_title,
        page_content: page.page_content,
        date: page.date,
        page_id: page.page_id
        };
    return this._http.put(pageUrl, data, {params})
    .map((res: Response) => {
        res.json();
    });
    }

// delete page
    deleteusers(page_id: number) {
    const pageUrl = 'http://localhost:8080/api/pages/delete/' + page_id;
    return this._http.delete(pageUrl, this.options)
    .map((res: Response) => {
    JSON.stringify(res);
    });
    }



}
