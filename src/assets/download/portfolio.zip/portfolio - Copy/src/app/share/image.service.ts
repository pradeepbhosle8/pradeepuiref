import { Injectable } from '@angular/core';

import { Http, Response, Headers, RequestMethod, RequestOptions } from '@angular/http';
import { HttpClient, HttpHeaders, HttpParams, HttpResponse } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/toPromise';
import { from } from 'rxjs';
import { Body } from '@angular/http/src/body';

import { Portfolio } from './portfolio.module';


@Injectable({
  providedIn: 'root'
})
export class ImageService {
    port: Portfolio;
    selectedPortfolio: Portfolio;
    public files: any[];
    page: Portfolio;
        private headers = new Headers({'Content-Type': 'application/json'});
        private headers1 = new HttpHeaders({ 'Content-Type': 'application/x-www-form-urlencoded' });
       
         private options = new RequestOptions({headers: this.headers});

  constructor(
      private _http: Http
  ) { }



    getCategoryList() {
    const pageurl = 'http://localhost:8080/api/category';
    return this._http.get(pageurl, this.options)
    .map((res: Response) => {
    return {status: res.status, result: res.json() };
    });
    }

    getImages() {
    const pageurl = 'http://localhost:8080/api/portfolio';
    return this._http.get(pageurl, this.options)
    .map((res: Response) => {
    // console.log(res.json()) ;
    return {status: res.status, result: res.json() };
    });
    }

    getImage(port_id: number) {
    const pageurl = 'http://localhost:8080/api/portfolio/' + port_id;
    return this._http.get(pageurl, this.options)
    .map((res: Response) => {
    return {status: res.status, result: res.json() };
    // res.json();
    });

    }


    addPortfoliolist(port: Portfolio,  fileToUpload: File) {
    const pageurl = 'http://localhost:8080/api/portfolio/add';
    const formData: FormData = new FormData();
    formData.append('url', fileToUpload, fileToUpload.name);
    formData.append('caption', port.caption);
    formData.append('client', port.client);
    formData.append('date', port.date);
    formData.append('skill', port.skill);
    formData.append('description', port.description);
    formData.append('cat_id', port.cat_id);
    formData.append('visit_website', port.visit_website);
     return this._http.post(pageurl, formData)
    .map((res: Response) => {
        console.log(res.json());
    return {status: res.status, result: res.json() };
    });
    }

    //  edit portfolio master
    EditPortfoliolist(port_id, port) {
    
    const pageUrl = 'http://localhost:8080/api/portfolio/update/' + port.port_id;
    console.log(pageUrl);
    const params = new HttpParams().set('port_id', port.port_id);
    const data = {
        cat_id: port.cat_id,
        caption: port.caption,
        url: port.url,
        client: port.client,
        date: port.date,
        skill: port.skill,
        description: port.description,
        visit_website: port.visit_website
          };
    return this._http.put(pageUrl, data, {params})
    .map((res: Response) => res.json());
    }

 // delete
     deletePortfolioList(port_id: number) {
        const pageUrl = 'http://localhost:8080/api/portfolio/delete/' + port_id;
         return this._http.delete(pageUrl, this.options)
         .map((res: Response) => {
          JSON.stringify(res);
        });
        }

}

