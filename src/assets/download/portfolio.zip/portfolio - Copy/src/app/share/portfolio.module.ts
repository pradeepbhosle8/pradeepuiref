export class Portfolio {
    port_id: number;
 
    cat_id: string;
    caption: string;
    url: string;
    client: string;
    date: string;
    skill: string;
    description: string;
    visit_website: string;
}
