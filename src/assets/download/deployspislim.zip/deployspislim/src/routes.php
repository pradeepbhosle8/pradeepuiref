<?php

// admin_mst section 
require __DIR__ . '/api/admin_mst.php'; 


// category_mst section 
require __DIR__ . '/api/category_mst.php'; 

// Pages section 
require __DIR__ . '/api/pages_mst.php'; 

// Portfolio section 
require __DIR__ . '/api/portfolio_mst.php';

// Experience section 
require __DIR__ . '/api/expreience_mst.php'; 

// Experience section 
require __DIR__ . '/api/education_mst.php'; 



  