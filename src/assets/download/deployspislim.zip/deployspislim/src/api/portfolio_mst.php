<?php



    $app->get('/api/portfolio', function ($request, $response, $args) {
    $sth = $this->db->prepare("SELECT * FROM portfolio_mst RIGHT JOIN category_mst ON portfolio_mst.cat_id = category_mst.cat_id ");
    $sth->execute();
    $data = $sth->fetchAll();
    return $this->response->withJson($data);
    });

   


// get all record from portfolio
    $app->get('/api/port', function ($request, $response, $args) {
    $sth = $this->db->prepare("SELECT * FROM portfolio_mst ORDER BY port_id");
    $sth->execute();
    $data = $sth->fetchAll();
    return $this->response->withJson($data);
    });

    // Retrieve portfolio with id record
    $app->get('/api/portfolio/[{port_id}]', function ($request, $response, $args) {
    $sth = $this->db->prepare("SELECT * FROM portfolio_mst WHERE port_id=:port_id");
    $sth->bindParam("port_id", $args['port_id']);
    $sth->execute();

    $data = $sth->fetchObject();
    
    return $this->response->withJson($data);
    });



    // Add a new portfolio record
     $app->post('/api/portfolio/add', function($request, $response, $args) {
    // do something with $newfile

     


     $image= $_FILES['url']['name'];

     $temp_dir= $_FILES['url']['tmp_name'];
     
    $imageSize= $_FILES['url']['size'];

     $upload_dir= './uploads/';

    $imgExt= strtolower(pathinfo($image, PATHINFO_EXTENSION));

     $valid_extenstions= array('jpeg', 'jpg', 'png', 'gif', 'pdf');

     $picProfile=$image;
      
     move_uploaded_file($temp_dir, $upload_dir.$picProfile); 	

    $input = $request->getParsedBody();
    $sql = "INSERT INTO portfolio_mst (cat_id, caption, url, client, date, skill, description, visit_website) VALUES (:cat_id, :caption, :url, :client, :date, :skill, :description, :visit_website )";
    $sth = $this->db->prepare($sql);
    $sth->bindParam("cat_id", $input['cat_id']);
    $sth->bindParam("caption", $input['caption']);
    $sth->bindParam("url",  $picProfile);
    $sth->bindParam("client", $input['client']);
    $sth->bindParam("date", $input['date']);
    $sth->bindParam("skill", $input['skill']);
    $sth->bindParam("description", $input['description']);
    $sth->bindParam("visit_website", $input['visit_website']);

    $sth->execute();
    $input['port_id'] = $this->db->lastInsertId();
    return $this->response->withJson($input);    
    });


     // DELETE a portfolio with given id
    $app->delete('/api/portfolio/delete/[{port_id}]', function ($request, $response, $args) {
    $stmt_delete = $this->db->prepare(" DELETE FROM portfolio_mst WHERE port_id=:port_id");
    $stmt_delete->bindParam("port_id", $args['port_id']);
    $stmt_delete->execute();
    // $result = $stmt_delete->fetchAll();
    // return $this->response->withJson($result);
    echo "Delete record Sucesfully!";
    }); 


    // Update portfolio with given id
    $app->put('/api/portfolio/update/[{port_id}]', function ($request, $response, $args) {
	$input = $request->getParsedBody();
    $sql = "UPDATE portfolio_mst SET cat_id=:cat_id, caption=:caption, url=:url, client=:client, date=:date, skill=:skill, description=:description, visit_website=:visit_website WHERE port_id=:port_id";
    $sth = $this->db->prepare($sql);
    $sth->bindParam("port_id", $args['port_id']);
    $sth->bindParam("cat_id", $input['cat_id']);
    $sth->bindParam("caption", $input['caption']);
    $sth->bindParam("url",  $input['url']);
    $sth->bindParam("client", $input['client']);
    $sth->bindParam("date", $input['date']);
    $sth->bindParam("skill", $input['skill']);
    $sth->bindParam("description", $input['description']);
    $sth->bindParam("visit_website", $input['visit_website']);
    $sth->execute();
    $input['port_id'] = $args['port_id'];
    return $this->response->withJson($input);
    }); 







?>