<?php

// get all record from pages
    $app->get('/api/pages', function ($request, $response, $args) {
    $sth = $this->db->prepare("SELECT * FROM pages_mst ORDER BY page_id");
    $sth->execute();
    $data = $sth->fetchAll();
    return $this->response->withJson($data);
    });

// Retrieve pages with id record
    $app->get('/api/pages/[{page_id}]', function ($request, $response, $args) {
    $sth = $this->db->prepare("SELECT * FROM pages_mst WHERE page_id=:page_id");
    $sth->bindParam("page_id", $args['page_id']);
    $sth->execute();

    $data = $sth->fetchObject();
    
    return $this->response->withJson($data);
    });

     // Add a new pages record
     $app->post('/api/pages/add', function($request, $response, $args) {
    $input = $request->getParsedBody();
    $sql = "INSERT INTO pages_mst (page_title, page_content, date) VALUES (:page_title, :page_content, :date)";
    $sth = $this->db->prepare($sql);
    $sth->bindParam("page_title", $input['page_title']);
    $sth->bindParam("page_content", $input['page_content']);
    $sth->bindParam("date", $input['date']);
    $sth->execute();
    $input['page_id'] = $this->db->lastInsertId();
    return $this->response->withJson($input);    
    });

      // DELETE a pages with given id
    $app->delete('/api/pages/delete/[{page_id}]', function ($request, $response, $args) {
    $stmt_delete = $this->db->prepare(" DELETE FROM pages_mst WHERE page_id=:page_id");
    $stmt_delete->bindParam("page_id", $args['page_id']);
    $stmt_delete->execute();
    // $result = $stmt_delete->fetchAll();
    // return $this->response->withJson($result);
    echo "Delete record Sucesfully!";
    }); 

    // Update pages with given id
    $app->put('/api/pages/update/[{page_id}]', function ($request, $response, $args) {
    $input = $request->getParsedBody();
    $sql = "UPDATE pages_mst SET page_title=:page_title, page_content=:page_content, date=:date WHERE page_id=:page_id";
    $sth = $this->db->prepare($sql);
    $sth->bindParam("page_id", $args['page_id']);
    $sth->bindParam("page_title", $input['page_title']);
    $sth->bindParam("page_content", $input['page_content']);
    $sth->bindParam("date", $input['date']);
    $sth->execute();
    $input['page_id'] = $args['page_id'];
    return $this->response->withJson($input);
    }); 

?>