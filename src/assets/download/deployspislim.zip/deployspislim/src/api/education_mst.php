<?php

// Education section api all

    // get all record fro education
    $app->get('/api/education', function ($request, $response, $args) {
    $sth = $this->db->prepare("SELECT * FROM education_mst ORDER BY educ_id");
    $sth->execute();
    $data = $sth->fetchAll();
    return $this->response->withJson($data);
    });

    // Retrieve education with id record
    $app->get('/api/education/[{educ_id}]', function ($request, $response, $args) {
    $sth = $this->db->prepare("SELECT * FROM education_mst WHERE educ_id=:educ_id");
    $sth->bindParam("educ_id", $args['educ_id']);
    $sth->execute();

    $data = $sth->fetchObject();
    
    return $this->response->withJson($data);
    }); 

    // Add a new education record
    $app->post('/api/education/add', function ($request, $response) {
    $input = $request->getParsedBody();
    $sql = "INSERT INTO education_mst (title, university, description,passing_year) VALUES (:title, :university, :description, :passing_year)";
    $sth = $this->db->prepare($sql);
    $sth->bindParam("title", $input['title']);
    $sth->bindParam("university", $input['university']);
    $sth->bindParam("description", $input['description']);
    $sth->bindParam("passing_year", $input['passing_year']);
    $sth->execute();

    $input['educ_id'] = $this->db->lastInsertId();
    return $this->response->withJson($input);
    });  

    // DELETE a education with given id
    $app->delete('/api/education/delete/[{educ_id}]', function ($request, $response, $args) {
    $stmt_delete = $this->db->prepare(" DELETE FROM education_mst WHERE educ_id=:educ_id");
    $stmt_delete->bindParam("educ_id", $args['educ_id']);
    $stmt_delete->execute();
    // $result = $stmt_delete->fetchAll();
    // return $this->response->withJson($result);
    echo "Delete record Sucesfully!";
    });  

    // Update education with given id
    $app->put('/api/education/update/[{educ_id}]', function ($request, $response, $args) {
    $input = $request->getParsedBody();
    $sql = "UPDATE education_mst SET title=:title, university=:university, description=:description, passing_year=:passing_year WHERE educ_id=:educ_id";
    $sth = $this->db->prepare($sql);
    $sth->bindParam("educ_id", $args['educ_id']);
    $sth->bindParam("title", $input['title']);
    $sth->bindParam("university", $input['university']);
    $sth->bindParam("description", $input['description']);
    $sth->bindParam("passing_year", $input['passing_year']);
     $sth->execute();
    $input['educ_id'] = $args['educ_id'];
    return $this->response->withJson($input);
    });

   

// education section api all close

    ?>