 <?php

 // get all record from category
    $app->get('/api/category', function ($request, $response, $args) {
    $sth = $this->db->prepare("SELECT * FROM category_mst ORDER BY cat_id");
    $sth->execute();
    $data = $sth->fetchAll();
    return $this->response->withJson($data);
    });

    // Retrieve category with id record
    $app->get('/api/category/[{cat_id}]', function ($request, $response, $args) {
    $sth = $this->db->prepare("SELECT * FROM category_mst WHERE cat_id=:cat_id");
    $sth->bindParam("cat_id", $args['cat_id']);
    $sth->execute();

    $data = $sth->fetchObject();
    
    return $this->response->withJson($data);
    });

    // Add a new category record
     $app->post('/api/category/add', function($request, $response, $args) {
    $input = $request->getParsedBody();
    $sql = "INSERT INTO category_mst (category) VALUES (:category)";
    $sth = $this->db->prepare($sql);
    $sth->bindParam("category", $input['category']);
    $sth->execute();
    $input['cat_id'] = $this->db->lastInsertId();
    return $this->response->withJson($input);    
    });

     // DELETE a category with given id
    $app->delete('/api/category/delete/[{cat_id}]', function ($request, $response, $args) {
    $stmt_delete = $this->db->prepare(" DELETE FROM category_mst WHERE cat_id=:cat_id");
    $stmt_delete->bindParam("cat_id", $args['cat_id']);
    $stmt_delete->execute();
    // $result = $stmt_delete->fetchAll();
    // return $this->response->withJson($result);
    echo "Delete record Sucesfully!";
    }); 

    // Update category with given id
    $app->put('/api/category/update/[{cat_id}]', function ($request, $response, $args) {
    $input = $request->getParsedBody();
    $sql = "UPDATE category_mst SET category=:category WHERE cat_id=:cat_id";
    $sth = $this->db->prepare($sql);
    $sth->bindParam("cat_id", $args['cat_id']);
    $sth->bindParam("category", $input['category']);
    $sth->execute();
    $input['cat_id'] = $args['cat_id'];
    return $this->response->withJson($input);
    }); 


    ?>