<?php

// Expreience section api all

    // get all record fro admin
    $app->get('/api/expreience', function ($request, $response, $args) {
    $sth = $this->db->prepare("SELECT * FROM experience ORDER BY exprience_id");
    $sth->execute();
    $data = $sth->fetchAll();
    return $this->response->withJson($data);
    });

    // Retrieve expreience with id record
    $app->get('/api/expreience/[{exprience_id}]', function ($request, $response, $args) {
    $sth = $this->db->prepare("SELECT * FROM experience WHERE exprience_id=:exprience_id");
    $sth->bindParam("exprience_id", $args['exprience_id']);
    $sth->execute();

    $data = $sth->fetchObject();
    
    return $this->response->withJson($data);
    }); 

    // Add a new expreience record
    $app->post('/api/expreience/add', function ($request, $response) {
    $input = $request->getParsedBody();
    $sql = "INSERT INTO experience (start_year, end_year, exprience_title, office_name, exprience_description)VALUES (:start_year, :end_year, :exprience_title, :office_name, :exprience_description    )";
    $sth = $this->db->prepare($sql);
    $sth->bindParam("start_year", $input['start_year']);
    $sth->bindParam("end_year", $input['end_year']);
    $sth->bindParam("exprience_title", $input['exprience_title']);
    $sth->bindParam("office_name", $input['office_name']);
    $sth->bindParam("exprience_description", $input['exprience_description']);
    $sth->execute();

    $input['exprience_id'] = $this->db->lastInsertId();
    return $this->response->withJson($input);
    });  

    // DELETE a expreience with given id
    $app->delete('/api/expreience/delete/[{exprience_id}]', function ($request, $response, $args) {
    $stmt_delete = $this->db->prepare(" DELETE FROM experience WHERE exprience_id=:exprience_id");
    $stmt_delete->bindParam("exprience_id", $args['exprience_id']);
    $stmt_delete->execute();
    // $result = $stmt_delete->fetchAll();
    // return $this->response->withJson($result);
    echo "Delete record Sucesfully!";
    });  

    // Update expreience with given id
    $app->put('/api/expreience/update/[{exprience_id}]', function ($request, $response, $args) {
    $input = $request->getParsedBody();
    $sql = "UPDATE experience SET start_year=:start_year, end_year=:end_year, exprience_title=:exprience_title, office_name=:office_name, exprience_description=:exprience_description  WHERE exprience_id=:exprience_id";
    $sth = $this->db->prepare($sql);
    $sth->bindParam("exprience_id", $args['exprience_id']);
    $sth->bindParam("start_year", $input['start_year']);
    $sth->bindParam("end_year", $input['end_year']);
    $sth->bindParam("exprience_title", $input['exprience_title']);
    $sth->bindParam("office_name", $input['office_name']);
    $sth->bindParam("exprience_description", $input['exprience_description']);
    
    $sth->execute();
    $input['exprience_id'] = $args['exprience_id'];
    return $this->response->withJson($input);
    });

  
// expreience section api all close

    ?>