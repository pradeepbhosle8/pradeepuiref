<?php

// admin section api all

    // get all record fro admin
    $app->get('/api/admin', function ($request, $response, $args) {
    $sth = $this->db->prepare("SELECT * FROM admin_mst ORDER BY admin_id");
    $sth->execute();
    $data = $sth->fetchAll();
    return $this->response->withJson($data);
    });

    // Retrieve admin with id record
    $app->get('/api/admin/[{admin_id}]', function ($request, $response, $args) {
    $sth = $this->db->prepare("SELECT * FROM admin_mst WHERE admin_id=:admin_id");
    $sth->bindParam("admin_id", $args['admin_id']);
    $sth->execute();

    $data = $sth->fetchObject();
    
    return $this->response->withJson($data);
    }); 

    // Add a new admin record
    $app->post('/api/admin/add', function ($request, $response) {
    $input = $request->getParsedBody();
    $sql = "INSERT INTO admin_mst (full_name, email_id, mobile_no, date, admin_img, username, password, gender) VALUES (:full_name, :email_id, :mobile_no, :date, :admin_img, :username, :password, :gender)";
    $sth = $this->db->prepare($sql);
    $sth->bindParam("full_name", $input['full_name']);
    $sth->bindParam("email_id", $input['email_id']);
    $sth->bindParam("mobile_no", $input['mobile_no']);
    $sth->bindParam("date", $input['date']);
    $sth->bindParam("admin_img", $input['admin_img']);
    $sth->bindParam("username", $input['username']);
    $sth->bindParam("password", $input['password']);
    $sth->bindParam("gender", $input['gender']);
    $sth->execute();

    $input['admin_id'] = $this->db->lastInsertId();
    return $this->response->withJson($input);
    });  

    // DELETE a admin with given id
    $app->delete('/api/admin/delete/[{admin_id}]', function ($request, $response, $args) {
    $stmt_delete = $this->db->prepare(" DELETE FROM admin_mst WHERE admin_id=:admin_id");
    $stmt_delete->bindParam("admin_id", $args['admin_id']);
    $stmt_delete->execute();
    // $result = $stmt_delete->fetchAll();
    // return $this->response->withJson($result);
    echo "Delete record Sucesfully!";
    });  

    // Update admin with given id
    $app->put('/api/admin/update/[{admin_id}]', function ($request, $response, $args) {
    $input = $request->getParsedBody();
    $sql = "UPDATE admin_mst SET full_name=:full_name, email_id=:email_id, mobile_no=:mobile_no, date=:date, admin_img=:admin_img, username=:username, password=:password, gender=:gender WHERE admin_id=:admin_id";
    $sth = $this->db->prepare($sql);
    $sth->bindParam("admin_id", $args['admin_id']);
    $sth->bindParam("full_name", $input['full_name']);
    $sth->bindParam("email_id", $input['email_id']);
    $sth->bindParam("mobile_no", $input['mobile_no']);
    $sth->bindParam("date", $input['date']);
    $sth->bindParam("admin_img", $input['admin_img']);
    $sth->bindParam("admin_img", $input['admin_img']);
    $sth->bindParam("username", $input['username']);
    $sth->bindParam("password", $input['password']);
    $sth->bindParam("gender", $input['gender']);
    $sth->execute();
    $input['admin_id'] = $args['admin_id'];
    return $this->response->withJson($input);
    });

    //login admin record
    $app->post('/api/admin/login', function ($request, $response, $args) {
    $input = $request->getParsedBody();
    $sth = $this->db->prepare("SELECT username, password FROM admin_mst WHERE username=:username and password=:password");
    $sth->bindParam("username", $input['username']);
    $sth->bindParam("password", $input['password']);
    $sth->execute();

    $todos = $sth->fetchAll();
  
    return $this->response->withJson($todos);
    });  

// admin section api all close

    ?>